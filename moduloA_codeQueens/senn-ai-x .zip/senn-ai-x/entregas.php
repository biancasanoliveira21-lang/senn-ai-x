<?php
require_once 'funcoes.php'; exigir_login(); validar_csrf();
$erro='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $acao=$_POST['acao']??'';
 if($acao==='cadastrar'){
  $codigo=strtoupper(trim($_POST['codigo']??'')); $dest=trim($_POST['destinatario']??''); $end=trim($_POST['endereco']??''); $cidade=trim($_POST['cidade']??'');
  $jan=trim($_POST['janela_entrega']??''); $peso=filter_var($_POST['peso_kg']??'0',FILTER_VALIDATE_FLOAT); $vol=filter_var($_POST['volume']??'0',FILTER_VALIDATE_FLOAT);
  $pri=$_POST['prioridade']??'Normal'; $obs=trim($_POST['observacoes']??'');
  if($codigo===''||strlen($codigo)>50||$dest===''||mb_strlen($dest)>120||$end===''||mb_strlen($end)>255||$cidade===''||mb_strlen($cidade)>120||$peso===false||$peso<0||$vol===false||$vol<0||!in_array($pri,['Normal','Alta','Urgente','Baixa','Média'],true)) $erro='Preencha os campos obrigatórios com valores válidos.';
  else {
   $data=null; if($jan!==''){ $dt=DateTime::createFromFormat('Y-m-d\TH:i',$jan); if(!$dt||$dt->format('Y-m-d\TH:i')!==$jan)$erro='Data/hora de entrega inválida.'; else $data=$dt->format('Y-m-d H:i:s');}
   if(!$erro){try{$q=$pdo->prepare("INSERT INTO entregas(codigo,destinatario,endereco,cidade,janela_entrega,peso_kg,volume,prioridade,status,observacoes) VALUES(?,?,?,?,?,?,?,?,'Pendente',?)");$q->execute([$codigo,$dest,$end,$cidade,$data,$peso,$vol,$pri,$obs]); flash('Entrega cadastrada.');header('Location: entregas.php');exit;}catch(PDOException $e){$erro='Não foi possível cadastrar. Confira se o código já existe e se a migração segura foi aplicada.';}}
  }
 } elseif($acao==='status'){
  $id=filter_var($_POST['id']??'',FILTER_VALIDATE_INT);$s=$_POST['status']??'';
  if($id&&status_entrega_valido($s)){$q=$pdo->prepare('UPDATE entregas SET status=? WHERE id=?');$q->execute([$s,$id]);flash('Status atualizado.');header('Location: entregas.php');exit;} $erro='Status ou código inválido.';
 } elseif($acao==='excluir'){
  $id=filter_var($_POST['id']??'',FILTER_VALIDATE_INT); if($id){$q=$pdo->prepare('DELETE FROM entregas WHERE id=?');$q->execute([$id]);flash('Entrega excluída.','ok');header('Location: entregas.php');exit;}
 }
}
if(isset($_GET['importar']) && $_SERVER['REQUEST_METHOD']==='POST'){}
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['acao']??'')==='importar_csv'){
 if(!isset($_FILES['csv'])||$_FILES['csv']['error']!==UPLOAD_ERR_OK)$erro='Selecione um CSV válido.';
 else{
  $fh=fopen($_FILES['csv']['tmp_name'],'r');$count=0;$line=0;
  if($fh){while(($row=fgetcsv($fh,2000,','))!==false){$line++;if($line===1&&strtolower(trim($row[0]??''))==='codigo')continue;if(count($row)<8)continue;
    [$c,$d,$a,$city,$date,$kg,$v,$p]=$row;
    if(trim($c)===''||trim($d)===''||trim($a)===''||trim($city)===''||!is_numeric($kg)||!is_numeric($v))continue;
    $p=in_array(trim($p),['Normal','Alta','Urgente','Baixa','Média'],true)?trim($p):'Normal';$date=trim($date)?:null;
    try{$q=$pdo->prepare("INSERT INTO entregas(codigo,destinatario,endereco,cidade,janela_entrega,peso_kg,volume,prioridade,status) VALUES(?,?,?,?,?,?,?,?,'Pendente')");$q->execute([trim($c),trim($d),trim($a),trim($city),$date, (float)$kg,(float)$v,$p]);$count++;}catch(Throwable $e){}
  }fclose($fh);flash("Importação concluída: {$count} registro(s) importado(s).");header('Location: entregas.php');exit;}
 }
}
$fstatus=$_GET['status']??'';$busca=trim($_GET['q']??'');
$sql='SELECT * FROM entregas WHERE 1=1';$args=[];
if($fstatus!==''&&status_entrega_valido($fstatus)){$sql.=' AND status=?';$args[]=$fstatus;}
if($busca!==''){$sql.=' AND (codigo LIKE ? OR destinatario LIKE ? OR cidade LIKE ?)';$args[]="%$busca%";$args[]="%$busca%";$args[]="%$busca%";}
$sql.=' ORDER BY id DESC';$q=$pdo->prepare($sql);$q->execute($args);$lista=$q->fetchAll();
layout_inicio('Entregas','Entregas');
if($erro) echo '<div class="alerta erro">'.h($erro).'</div>';
?>
<p class="subtitulo">Cadastro, filtros, atualização de status e importação em lote por CSV.</p>
<section class="painel"><h2>Nova entrega</h2><form method="post" class="formulario"><input type="hidden" name="csrf" value="<?=h(token_csrf())?>"><input type="hidden" name="acao" value="cadastrar">
<div class="campos-duplos"><div><label for="codigo">Código único *</label><input id="codigo" name="codigo" maxlength="50" required></div><div><label for="destinatario">Destinatário *</label><input id="destinatario" name="destinatario" maxlength="120" required></div></div>
<label for="endereco">Endereço *</label><input id="endereco" name="endereco" maxlength="255" required>
<div class="campos-duplos"><div><label for="cidade">Cidade/região *</label><input id="cidade" name="cidade" maxlength="120" required></div><div><label for="janela_entrega">Janela de entrega</label><input id="janela_entrega" name="janela_entrega" type="datetime-local"></div></div>
<div class="campos-duplos"><div><label for="peso_kg">Peso (kg)</label><input id="peso_kg" name="peso_kg" type="number" min="0" step=".01" value="0" required></div><div><label for="volume">Volume (m³)</label><input id="volume" name="volume" type="number" min="0" step=".01" value="0" required></div></div>
<div class="campos-duplos"><div><label for="prioridade">Prioridade</label><select id="prioridade" name="prioridade"><option>Normal</option><option>Alta</option><option>Urgente</option></select></div><div><label for="observacoes">Observações</label><input id="observacoes" name="observacoes" maxlength="1000"></div></div>
<button type="submit">Cadastrar entrega</button></form></section>
<section class="painel"><h2>Importar CSV</h2><p>Colunas: <code>codigo,destinatario,endereco,cidade,janela_entrega,peso_kg,volume,prioridade</code>. Data no formato MySQL (AAAA-MM-DD HH:MM:SS) ou vazia.</p>
<form method="post" enctype="multipart/form-data" class="formulario"><input type="hidden" name="csrf" value="<?=h(token_csrf())?>"><input type="hidden" name="acao" value="importar_csv"><label for="csv">Arquivo CSV (separador vírgula)</label><input type="file" id="csv" name="csv" accept=".csv,text/csv" required><button>Importar arquivo</button></form></section>
<section class="painel"><h2>Consultar entregas</h2><form method="get" class="filtros"><input name="q" value="<?=h($busca)?>" placeholder="Buscar código, destinatário ou cidade"><select name="status"><option value="">Todos os status</option><?php foreach(['Pendente','A caminho','Entregue','Falha'] as $s):?><option <?= $fstatus===$s?'selected':''?>><?=h($s)?></option><?php endforeach;?></select><button>Filtrar</button><a class="botao-link" href="entregas.php">Limpar</a></form>
<div class="tabela-responsiva"><table><thead><tr><th>Código</th><th>Destinatário</th><th>Cidade</th><th>Prioridade</th><th>Status</th><th>Janela</th><th>Atualizar</th><th>Excluir</th></tr></thead><tbody>
<?php foreach($lista as $e):?><tr><td><?=h($e['codigo'])?></td><td><?=h($e['destinatario'])?></td><td><?=h($e['cidade'])?></td><td><?=h($e['prioridade'])?></td><td><?=h($e['status'])?></td><td><?=h($e['janela_entrega']?:'—')?></td><td><form method="post" class="form-inline"><input type="hidden" name="csrf" value="<?=h(token_csrf())?>"><input type="hidden" name="acao" value="status"><input type="hidden" name="id" value="<?=(int)$e['id']?>"><select name="status"><?php foreach(['Pendente','A caminho','Entregue','Falha'] as $s):?><option <?= $e['status']===$s?'selected':''?>><?=h($s)?></option><?php endforeach;?></select><button>Salvar</button></form><a href="comprovantes.php?entrega=<?=(int)$e['id']?>">Comprovante</a></td><td><form method="post" onsubmit="return confirm('Excluir esta entrega?')"><input type="hidden" name="csrf" value="<?=h(token_csrf())?>"><input type="hidden" name="acao" value="excluir"><input type="hidden" name="id" value="<?=(int)$e['id']?>"><button class="botao-excluir">Excluir</button></form></td></tr><?php endforeach;?>
<?php if(!$lista):?><tr><td colspan="8">Nenhuma entrega encontrada.</td></tr><?php endif;?></tbody></table></div></section>
<?php layout_fim(); ?>
