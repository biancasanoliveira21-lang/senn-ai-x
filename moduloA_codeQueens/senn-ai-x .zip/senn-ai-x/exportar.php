<?php
require_once 'funcoes.php'; exigir_login();
header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="relatorio_entregas.csv"');
$out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");fputcsv($out,['Código','Destinatário','Endereço','Cidade','Janela de entrega','Peso kg','Volume','Prioridade','Status','Criado em'],';');
foreach($pdo->query('SELECT codigo,destinatario,endereco,cidade,janela_entrega,peso_kg,volume,prioridade,status,criado_em FROM entregas ORDER BY id DESC') as $r)fputcsv($out,$r,';');fclose($out);exit;
