-- MIGRAÇÃO SEGURA: selecione o banco existente cadastros antes de executar.
-- NÃO apaga tabelas nem registros. Faça backup do banco pelo phpMyAdmin antes.
USE cadastros;

-- Campos opcionais necessários para ampliar a aplicação.
ALTER TABLE entregas
  ADD COLUMN IF NOT EXISTS latitude DECIMAL(10,7) NULL,
  ADD COLUMN IF NOT EXISTS longitude DECIMAL(10,7) NULL,
  ADD COLUMN IF NOT EXISTS observacoes TEXT NULL,
  ADD COLUMN IF NOT EXISTS motorista_id INT NULL,
  ADD COLUMN IF NOT EXISTS veiculo_id INT NULL;

ALTER TABLE motoristas
  ADD COLUMN IF NOT EXISTS veiculo_id INT NULL;

ALTER TABLE veiculos
  ADD COLUMN IF NOT EXISTS autonomia_km INT NOT NULL DEFAULT 0;

ALTER TABLE entregas
  MODIFY COLUMN prioridade ENUM('Normal','Alta','Urgente','Baixa','Média') NOT NULL DEFAULT 'Normal';

CREATE TABLE IF NOT EXISTS comprovantes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  entrega_id INT NOT NULL,
  data_hora DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  latitude DECIMAL(10,7) NULL,
  longitude DECIMAL(10,7) NULL,
  tipo_evidencia ENUM('Código','Assinatura','Foto','Observação') NOT NULL DEFAULT 'Código',
  evidencia TEXT NOT NULL,
  criado_por INT NULL,
  INDEX idx_comprovantes_entrega (entrega_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rotas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  data_rota DATE NOT NULL,
  veiculo_id INT NULL,
  motorista_id INT NULL,
  entrega_ids TEXT NOT NULL,
  distancia_estimada_km DECIMAL(10,2) NOT NULL DEFAULT 0,
  status ENUM('Planejada','Liberada','Concluída') NOT NULL DEFAULT 'Planejada',
  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rota_entregas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  rota_id INT NOT NULL,
  entrega_id INT NOT NULL,
  ordem INT NOT NULL,
  UNIQUE KEY uq_rota_entrega (rota_id, entrega_id),
  INDEX idx_re_entrega (entrega_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS logs_notificacoes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  alerta_id INT NULL,
  canal VARCHAR(30) NOT NULL DEFAULT 'painel',
  resultado VARCHAR(80) NOT NULL DEFAULT 'registrado',
  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
