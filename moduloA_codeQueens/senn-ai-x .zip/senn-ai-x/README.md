# SENN AI-X — Gestão logística

Projeto PHP + MySQL para XAMPP, alinhado ao desafio SENAI Dev Experience — Módulo A 2026.

## Instalação segura
**Não importe `banco.sql` no banco atual.** Esse arquivo é somente referência para banco novo; use `migracao_segura.sql` no banco `cadastros` existente.
1. Inicie Apache e MySQL no XAMPP.
2. Faça backup do banco `cadastros` no phpMyAdmin (Exportar → SQL). **Não apague nem recrie o banco.**
3. Copie a pasta `senn-ai-x` para `C:\xampp\htdocs\`.
4. Confira usuário e senha do MySQL em `conexao.php` (padrão XAMPP: `root` sem senha).
5. No phpMyAdmin, selecione o banco existente `cadastros`, abra a aba SQL e execute `migracao_segura.sql`. A migração adiciona campos/tabelas e não apaga registros. Se sua versão do MariaDB não aceitar `ADD COLUMN IF NOT EXISTS`, execute os `ALTER TABLE` individualmente apenas para colunas que ainda não existem.
6. Acesse `http://localhost/senn-ai-x/login.php`.
7. Crie uma conta de administrador na tela de primeiro acesso e entre.

## Recursos presentes
- Cadastro/login com hash de senha, sessão e token CSRF nos formulários principais.
- Painel com contadores e entregas recentes.
- CRUD básico de entregas, filtros e importação CSV.
- Cadastro e exclusão de veículos e motoristas, com vínculo de motorista/veículo.
- Planejamento de rota por heurística local (agrupamento por cidade, prioridade e janela de entrega).
- Rastreamento em mapa quando a biblioteca/tiles externos estão disponíveis; modo lista se estiver offline. Marcadores só aparecem se coordenadas forem cadastradas.
- Registro de comprovante, localização opcional e atualização de status para Entregue.
- Indicadores históricos, recomendações por regras locais e assistente de perguntas frequentes baseado nos dados.
- Verificação de alertas de prazo, manutenção e CNH; resolução e log no painel.
- Exportação CSV compatível com Excel e impressão do relatório em PDF pelo navegador.

## Transparência técnica / limitações
- A roteirização é uma heurística demonstrativa, não um solver VRP/TSP nem uma integração com serviço de mapas.
- A previsão atual mostra histórico recente como proxy; não é modelo treinado e não prevê matematicamente os próximos 7/30 dias.
- O assistente é baseado em regras locais, não uma integração com OpenAI/Gemini. Nenhuma chave de API é necessária.
- Rastreamento não é GPS contínuo. Para coordenadas reais, é necessário coletar localização consentida no dispositivo e armazená-la.
- E-mail, upload de foto real, assinatura digital capturada e integração de IA externa exigem configuração adicional.
- A integração com mapas usa Leaflet/OpenStreetMap via internet; sem internet, a lista permanece disponível.
- O relatório PDF pode ser gerado pelo navegador com Imprimir → Salvar como PDF.

## CSV de entregas
Cabeçalho recomendado:
`codigo,destinatario,endereco,cidade,janela_entrega,peso_kg,volume,prioridade`
Use vírgula como separador. Exemplo de janela: `2026-10-22 14:30:00`.

## Segurança e dados
Use HTTPS e política de acesso adequada em produção; configure backups automáticos, permissões por perfil, consentimento LGPD, envio SMTP e integração real de IA/mapas antes de uso empresarial. Este projeto é uma base de demonstração acadêmica.
