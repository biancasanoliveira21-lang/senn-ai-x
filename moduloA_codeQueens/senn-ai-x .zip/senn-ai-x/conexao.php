<?php
declare(strict_types=1);
/* Ajuste estas credenciais para seu XAMPP. O banco existente cadastros será preservado. */
$host = 'localhost';
$banco = 'cadastros';
$usuario = 'root';
$senha = '';
try {
    $pdo = new PDO("mysql:host={$host};dbname={$banco};charset=utf8mb4", $usuario, $senha, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    exit('Não foi possível conectar ao banco. Confira o XAMPP, o banco cadastros e as credenciais em conexao.php.');
}
