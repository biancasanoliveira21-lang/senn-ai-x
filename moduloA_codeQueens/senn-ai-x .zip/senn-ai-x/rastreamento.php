<?php
require_once 'funcoes.php'; exigir_login();
$rota=(int)($_GET['rota']??0);$args=[];$sql='SELECT e.* FROM entregas e';if($rota){$sql.=' JOIN rota_entregas re ON re.entrega_id=e.id WHERE re.rota_id=?';$args[]=$rota;}else{$sql.=" WHERE e.status IN ('Pendente','A caminho','Falha')";}
$sql.=' ORDER BY e.cidade,e.id DESC';$q=$pdo->prepare($sql);$q->execute($args);$lista=$q->fetchAll();
layout_inicio('Rastreamento','Rastreamento');
?>
<p class="subtitulo">Mapa operacional com marcadores aproximados por cidade quando não há coordenadas registradas. Não representa GPS em tempo real.</p>
<section class="painel"><div id="mapa" class="mapa"><p>Mapa externo indisponível? Use a lista de entregas abaixo. Para mapa interativo, é necessária conexão com a internet.</p></div></section>
<section class="painel"><h2>Entregas monitoradas</h2><div class="tabela-responsiva"><table><thead><tr><th>Código</th><th>Destino</th><th>Cidade</th><th>Status</th><th>Janela</th></tr></thead><tbody><?php foreach($lista as $e):?><tr><td><?=h($e['codigo'])?></td><td><?=h($e['endereco'])?></td><td><?=h($e['cidade'])?></td><td><?=h($e['status'])?></td><td><?=h($e['janela_entrega']?:'—')?></td></tr><?php endforeach;?><?php if(!$lista):?><tr><td colspan="5">Nenhuma entrega para rastrear.</td></tr><?php endif;?></tbody></table></div></section>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"><script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
(function(){const el=document.getElementById('mapa'); if(!window.L){el.innerHTML='<p>O mapa não carregou. A lista de entregas continua disponível no modo fallback.</p>';return;}
 const map=L.map('mapa').setView([-23.02,-45.55],8);
 L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'&copy; OpenStreetMap contributors'}).addTo(map);
 const pontos=<?=json_encode(array_map(function($e){return ['codigo'=>$e['codigo'],'dest'=>$e['destinatario'],'cidade'=>$e['cidade'],'status'=>$e['status'],'lat'=>$e['latitude'],'lng'=>$e['longitude']];},$lista),JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP)?>;
 // Sem geocodificação, não inventamos coordenadas de endereço; mostramos marcadores apenas para coordenadas salvas.
 const validos=pontos.filter(p=>p.lat!==null&&p.lng!==null);validos.forEach(p=>L.marker([Number(p.lat),Number(p.lng)]).addTo(map).bindPopup('<b>'+String(p.codigo).replace(/[<>&"]/g,'')+'</b><br>'+String(p.cidade).replace(/[<>&"]/g,'')+'<br>'+String(p.status).replace(/[<>&"]/g,'')));
 if(!validos.length){el.insertAdjacentHTML('beforeend','<p>Nenhuma entrega possui latitude/longitude cadastrada. Cadastre coordenadas para posicionar marcadores.</p>');}
})();
</script>
<?php layout_fim();?>
