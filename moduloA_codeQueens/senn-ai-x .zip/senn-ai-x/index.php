<?php
require_once 'funcoes.php'; exigir_login();
$tot=$pdo->query("SELECT COUNT(*) total, SUM(status='Pendente') pendentes, SUM(status='A caminho') caminho, SUM(status='Entregue') entregues, SUM(status='Falha') falhas FROM entregas")->fetch() ?: [];
$veic=(int)$pdo->query("SELECT COUNT(*) FROM veiculos")->fetchColumn();
$motor=(int)$pdo->query("SELECT COUNT(*) FROM motoristas")->fetchColumn();
$alertas=(int)$pdo->query("SELECT COUNT(*) FROM alertas WHERE resolvido=0")->fetchColumn();
$recentes=$pdo->query("SELECT * FROM entregas ORDER BY id DESC LIMIT 8")->fetchAll();
layout_inicio('Painel gerencial','Painel');
?>
<p class="subtitulo">Resumo operacional da frota e das entregas cadastradas.</p>
<section class="indicadores">
<div class="indicador"><p>Total de entregas</p><strong><?= (int)($tot['total']??0) ?></strong></div>
<div class="indicador"><p>Pendentes</p><strong><?= (int)($tot['pendentes']??0) ?></strong></div>
<div class="indicador"><p>Entregues</p><strong><?= (int)($tot['entregues']??0) ?></strong></div>
<div class="indicador"><p>Veículos</p><strong><?=$veic?></strong></div>
<div class="indicador"><p>Motoristas</p><strong><?=$motor?></strong></div>
<div class="indicador"><p>Alertas em aberto</p><strong><?=$alertas?></strong></div>
</section>
<section class="painel"><div class="linha-cabecalho"><h2>Entregas recentes</h2><a class="botao-link" href="entregas.php">Gerenciar entregas</a></div>
<div class="tabela-responsiva"><table><thead><tr><th>Código</th><th>Destinatário</th><th>Cidade</th><th>Prioridade</th><th>Status</th><th>Janela</th></tr></thead><tbody>
<?php foreach($recentes as $e): ?><tr><td><?=h($e['codigo'])?></td><td><?=h($e['destinatario'])?></td><td><?=h($e['cidade'])?></td><td><?=h($e['prioridade'])?></td><td><span class="status"><?=h($e['status'])?></span></td><td><?=h($e['janela_entrega']?:'—')?></td></tr><?php endforeach; ?>
<?php if(!$recentes): ?><tr><td colspan="6">Nenhuma entrega cadastrada. Comece em Entregas.</td></tr><?php endif; ?></tbody></table></div></section>
<section class="painel"><h2>Acesso rápido</h2><div class="atalhos"><a class="botao-link" href="rotas.php">Planejar rotas</a><a class="botao-link" href="rastreamento.php">Ver rastreamento</a><a class="botao-link" href="ia.php">Previsão e análise</a><a class="botao-link" href="alertas.php">Central de alertas</a></div></section>
<?php layout_fim(); ?>
