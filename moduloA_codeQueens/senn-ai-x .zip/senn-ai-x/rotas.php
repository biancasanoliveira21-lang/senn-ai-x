<?php
require_once 'funcoes.php'; exigir_login(); validar_csrf(); $erro='';
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['acao']??'')==='planejar'){
 $nome=trim($_POST['nome']??'Rota diária');$vid=(int)($_POST['veiculo_id']??0);$mid=(int)($_POST['motorista_id']??0);$ids=array_values(array_unique(array_filter(array_map('intval',$_POST['entregas']??[]))));
 if(!$ids)$erro='Selecione pelo menos uma entrega pendente.';
 else{
  $ph=implode(',',array_fill(0,count($ids),'?'));$q=$pdo->prepare("SELECT * FROM entregas WHERE id IN ($ph) AND status IN ('Pendente','A caminho')");$q->execute($ids);$es=$q->fetchAll();
  if(!$es)$erro='Não há entregas válidas para planejar.';
  else{
   // Confere capacidade do veículo antes de gravar a rota.
   if($vid){
    $qv=$pdo->prepare("SELECT * FROM veiculos WHERE id=? AND status='Disponível'");$qv->execute([$vid]);$veiculo=$qv->fetch();
    $pesoTotal=array_sum(array_map(fn($e)=>(float)$e['peso_kg'],$es));
    $volumeTotal=array_sum(array_map(fn($e)=>(float)$e['volume'],$es));
    if(!$veiculo)$erro='O veículo selecionado não está disponível.';
    elseif($pesoTotal>(float)$veiculo['capacidade_kg'] || $volumeTotal>(float)$veiculo['capacidade_volume'])$erro='A soma do peso/volume das entregas excede a capacidade do veículo.';
   }
   if(!$erro){
   // Heurística simples e documentada: agrupa por cidade, depois ordena por janela/prioridade.
   usort($es,function($a,$b){$city=strcmp($a['cidade'],$b['cidade']);if($city!==0)return $city;$p=['Urgente'=>0,'Alta'=>1,'Média'=>2,'Baixa'=>3,'Normal'=>4];$d=($p[$a['prioridade']]??4)<=>($p[$b['prioridade']]??4);if($d!==0)return $d;return strcmp($a['janela_entrega']??'9999',$b['janela_entrega']??'9999');});
   $ord=array_column($es,'id');$idsText=implode(',',$ord);$dist=max(1,count($ord))*8.5;
   $pdo->beginTransaction();try{$q=$pdo->prepare("INSERT INTO rotas(nome,data_rota,veiculo_id,motorista_id,entrega_ids,distancia_estimada_km,status) VALUES(?,?,?,?,?,?,'Planejada')");$q->execute([$nome?:'Rota diária',date('Y-m-d'),$vid?:null,$mid?:null,$idsText,$dist]);$rid=(int)$pdo->lastInsertId();
    $ins=$pdo->prepare('INSERT INTO rota_entregas(rota_id,entrega_id,ordem) VALUES(?,?,?)');foreach($ord as $i=>$eid)$ins->execute([$rid,$eid,$i+1]);$pdo->commit();flash('Rota planejada por heurística local. A distância é apenas estimativa.');header('Location: rotas.php');exit;
   }catch(Throwable $e){$pdo->rollBack();$erro='Não foi possível salvar a rota. Execute migracao_segura.sql.';}
   }
  }
 }
}
$pend=$pdo->query("SELECT * FROM entregas WHERE status IN ('Pendente','A caminho') ORDER BY cidade,janela_entrega")->fetchAll();$veic=$pdo->query("SELECT id,placa,tipo,capacidade_kg,capacidade_volume,status FROM veiculos WHERE status='Disponível' ORDER BY placa")->fetchAll();$mot=$pdo->query("SELECT id,nome FROM motoristas WHERE disponibilidade='Disponível' ORDER BY nome")->fetchAll();
$rotas=$pdo->query('SELECT r.*,v.placa,m.nome motorista FROM rotas r LEFT JOIN veiculos v ON v.id=r.veiculo_id LEFT JOIN motoristas m ON m.id=r.motorista_id ORDER BY r.id DESC')->fetchAll();
layout_inicio('Planejamento de rotas','Rotas');if($erro)echo '<div class="alerta erro">'.h($erro).'</div>';
?>
<p class="subtitulo">Planejamento demonstrativo com heurística local: agrupa por cidade e prioriza urgência/janela. Não é um serviço de navegação nem uma IA treinada.</p>
<section class="painel"><h2>Gerar rota</h2><form method="post" class="formulario"><input type="hidden" name="csrf" value="<?=h(token_csrf())?>"><input type="hidden" name="acao" value="planejar"><label for="nome">Nome da rota</label><input id="nome" name="nome" value="Rota diária <?=date('d/m/Y')?>"><div class="campos-duplos"><div><label for="veiculo_id">Veículo disponível</label><select id="veiculo_id" name="veiculo_id"><option value="0">Não atribuir</option><?php foreach($veic as $v):?><option value="<?=(int)$v['id']?>"><?=h($v['placa'].' — '.$v['tipo'].' ('.$v['capacidade_kg'].' kg)')?></option><?php endforeach;?></select></div><div><label for="motorista_id">Motorista disponível</label><select id="motorista_id" name="motorista_id"><option value="0">Não atribuir</option><?php foreach($mot as $m):?><option value="<?=(int)$m['id']?>"><?=h($m['nome'])?></option><?php endforeach;?></select></div></div><fieldset><legend>Entregas para incluir</legend><?php foreach($pend as $e):?><label class="check-item"><input type="checkbox" name="entregas[]" value="<?=(int)$e['id']?>"> <?=h($e['codigo'].' — '.$e['destinatario'].' / '.$e['cidade'].' / '.$e['prioridade'])?> (<?=h($e['peso_kg'])?> kg)</label><?php endforeach;?><?php if(!$pend):?><p>Não há entregas pendentes.</p><?php endif;?></fieldset><button <?=!$pend?'disabled':''?>>Planejar rota</button></form></section>
<section class="painel"><h2>Rotas planejadas</h2><div class="tabela-responsiva"><table><thead><tr><th>Rota</th><th>Data</th><th>Veículo</th><th>Motorista</th><th>Paradas</th><th>Distância estimada</th><th>Status</th><th>Detalhes</th></tr></thead><tbody><?php foreach($rotas as $r):$ids=array_filter(array_map('intval',explode(',',$r['entrega_ids'])));?><tr><td><?=h($r['nome'])?></td><td><?=h($r['data_rota'])?></td><td><?=h($r['placa']?:'—')?></td><td><?=h($r['motorista']?:'—')?></td><td><?=count($ids)?></td><td><?=h($r['distancia_estimada_km'])?> km*</td><td><?=h($r['status'])?></td><td><a href="rastreamento.php?rota=<?=(int)$r['id']?>">Ver paradas</a></td></tr><?php endforeach;?><?php if(!$rotas):?><tr><td colspan="8">Nenhuma rota planejada.</td></tr><?php endif;?></tbody></table></div><p class="nota">*Estimativa ilustrativa de 8,5 km por parada; não substitui distância calculada por mapa. Verifique capacidade do veículo antes de liberar a rota.</p></section>
<?php layout_fim();?>
