<?php
require_once 'funcoes.php'; exigir_login();
$stats=$pdo->query("SELECT COUNT(*) total, SUM(status='Entregue') entregues, SUM(status='Falha') falhas, SUM(status IN ('Pendente','A caminho')) abertas, AVG(peso_kg) peso_medio FROM entregas")->fetch();
$porCidade=$pdo->query("SELECT cidade,COUNT(*) total,SUM(status='Falha') falhas,SUM(status='Entregue') entregues FROM entregas GROUP BY cidade ORDER BY total DESC LIMIT 10")->fetchAll();
$proximos=[];foreach([7,30] as $dias){$q=$pdo->prepare("SELECT COUNT(*) FROM entregas WHERE criado_em >= DATE_SUB(NOW(), INTERVAL ? DAY)");$q->execute([$dias]);$proximos[$dias]=(int)$q->fetchColumn();}
$taxa=($stats['total']??0)>0?round(100*(int)$stats['entregues']/(int)$stats['total'],1):0;
$insights=[];
if(($stats['total']??0)==0)$insights[]='Ainda não há dados históricos suficientes. Cadastre entregas para gerar indicadores.';
else{
 $insights[]="Taxa histórica de entregas concluídas: {$taxa}%.";
 if((int)$stats['falhas']>0)$insights[]="Existem ".(int)$stats['falhas']." entrega(s) com falha. Revise endereço, janela de entrega e ocorrência registrada.";
 if((int)$stats['abertas']>5)$insights[]='Há mais de cinco entregas em aberto. Considere agrupar por cidade e prioridade ao planejar as rotas.';
 if(count($porCidade)>0)$insights[]='Região com maior volume cadastrado: '.$porCidade[0]['cidade'].' ('.$porCidade[0]['total'].' entrega(s)). Avalie alocação de frota para essa região.';
}
$pergunta=trim($_POST['pergunta']??'');$resposta='';
if($_SERVER['REQUEST_METHOD']==='POST'&&$pergunta!==''){
 $p=mb_strtolower($pergunta);
 if(str_contains($p,'falha')||str_contains($p,'atras'))$resposta='Há '.(int)($stats['falhas']??0).' entrega(s) com falha e '.(int)($stats['abertas']??0).' entrega(s) pendentes ou a caminho. Abra Entregas para revisar cada caso.';
 elseif(str_contains($p,'entreg'))$resposta='Total de entregas: '.(int)($stats['total']??0).'; concluídas: '.(int)($stats['entregues']??0).'; taxa histórica de conclusão: '.$taxa.'%.';
 elseif(str_contains($p,'veículo')||str_contains($p,'frota'))$resposta='Há '.$pdo->query('SELECT COUNT(*) FROM veiculos')->fetchColumn().' veículo(s) cadastrados, sendo '.$pdo->query("SELECT COUNT(*) FROM veiculos WHERE status='Disponível'")->fetchColumn().' disponível(is).';
 elseif(str_contains($p,'motorista'))$resposta='Há '.$pdo->query('SELECT COUNT(*) FROM motoristas')->fetchColumn().' motorista(s) cadastrado(s). Consulte a página Motoristas para validade de CNH e disponibilidade.';
 elseif(str_contains($p,'cidade')||str_contains($p,'região'))$resposta=count($porCidade)?'Maior volume cadastrado: '.$porCidade[0]['cidade'].' ('.$porCidade[0]['total'].' entrega(s)).':'Ainda não há dados agrupados por cidade.';
 else $resposta='Posso responder sobre entregas, falhas/atrasos, frota, motoristas e cidades. Esta versão usa regras locais e dados do banco; não é um modelo de IA externo.';
}
layout_inicio('IA e indicadores','IA e indicadores');
?>
<p class="subtitulo">Análise local explicável, sem dependência de API externa. A previsão abaixo é uma referência estatística do histórico, não uma previsão treinada.</p>
<section class="indicadores"><div class="indicador"><p>Entregas cadastradas</p><strong><?=(int)($stats['total']??0)?></strong></div><div class="indicador"><p>Taxa concluída</p><strong><?=$taxa?>%</strong></div><div class="indicador"><p>Falhas</p><strong><?=(int)($stats['falhas']??0)?></strong></div><div class="indicador"><p>Peso médio</p><strong><?=number_format((float)($stats['peso_medio']??0),1,',','.')?> kg</strong></div></section>
<section class="painel"><h2>Previsão de volume (referência)</h2><p>Entregas criadas no histórico recente — usado como proxy de volume, não como previsão real de demanda futura.</p><div class="indicadores"><div class="indicador"><p>Últimos 7 dias</p><strong><?=$proximos[7]?></strong></div><div class="indicador"><p>Últimos 30 dias</p><strong><?=$proximos[30]?></strong></div></div><p class="nota">Para cumprir integralmente o RF08, conectar um modelo de previsão e apresentar projeções futuras para 7 e 30 dias. Este modo local mantém o sistema funcionando sem API.</p></section>
<section class="painel"><h2>Análise inteligente / recomendações</h2><ul><?php foreach($insights as $i):?><li><?=h($i)?></li><?php endforeach;?></ul><div class="tabela-responsiva"><table><thead><tr><th>Cidade</th><th>Total</th><th>Concluídas</th><th>Falhas</th></tr></thead><tbody><?php foreach($porCidade as $c):?><tr><td><?=h($c['cidade'])?></td><td><?=(int)$c['total']?></td><td><?=(int)$c['entregues']?></td><td><?=(int)$c['falhas']?></td></tr><?php endforeach;?></tbody></table></div><button type="button" onclick="window.print()">Exportar / imprimir relatório PDF</button><a class="botao-link" href="exportar.php">Exportar dados CSV/Excel</a></section>
<section class="painel"><h2>SENN AI-X Helper</h2><p>Faça uma pergunta em linguagem natural sobre os dados atuais.</p><form method="post" class="formulario"><label for="pergunta">Sua pergunta</label><input id="pergunta" name="pergunta" value="<?=h($pergunta)?>" placeholder="Ex.: Quantas entregas estão com falha?"><button>Consultar assistente</button></form><?php if($resposta):?><div class="resposta-chat"><strong>Assistente:</strong> <?=h($resposta)?></div><?php endif;?></section>
<?php layout_fim();?>
