<?php
require_once 'funcoes.php';
if (isset($_GET['sair'])) { session_destroy(); header('Location: login.php'); exit; }
if (logado()) { header('Location: index.php'); exit; }
$erro='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    validar_csrf();
    $acao=$_POST['acao'] ?? 'entrar';
    $nome=trim($_POST['nome'] ?? '');
    $email=mb_strtolower(trim($_POST['email'] ?? ''));
    $senha=$_POST['senha'] ?? '';
    try {
      if ($acao==='cadastro') {
        if ($nome==='' || mb_strlen($nome)>120 || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($senha)<8) {
          $erro='Informe nome, e-mail válido e senha com pelo menos 8 caracteres.';
        } else {
          $q=$pdo->prepare('SELECT id FROM usuarios WHERE email=?'); $q->execute([$email]);
          if ($q->fetch()) $erro='Este e-mail já está cadastrado. Tente entrar.';
          else {
            $q=$pdo->prepare('INSERT INTO usuarios(nome,email,senha_hash,perfil) VALUES(?,?,?,?)');
            $q->execute([$nome,$email,password_hash($senha,PASSWORD_DEFAULT),'administrador']);
            $_SESSION['usuario_id']=(int)$pdo->lastInsertId(); $_SESSION['usuario_nome']=$nome; $_SESSION['perfil']='administrador';
            session_regenerate_id(true); header('Location: index.php'); exit;
          }
        }
      } else {
        $q=$pdo->prepare('SELECT * FROM usuarios WHERE email=?'); $q->execute([$email]); $u=$q->fetch();
        if ($u && password_verify($senha,$u['senha_hash'])) {
          session_regenerate_id(true); $_SESSION['usuario_id']=(int)$u['id']; $_SESSION['usuario_nome']=$u['nome']; $_SESSION['perfil']=$u['perfil'];
          header('Location: index.php'); exit;
        }
        $erro='E-mail ou senha incorretos.';
      }
    } catch (PDOException $e) { $erro='Não foi possível concluir a operação. Verifique se o e-mail já existe e se a migração foi aplicada.'; }
}
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Acesso | SENN AI-X</title><link rel="stylesheet" href="style.css"></head>
<body class="login-fundo"><main class="caixa-login"><a class="logo" href="login.php">SENN <span>AI-X</span></a><h1>Gestão logística inteligente</h1><p>Entre na plataforma ou crie o primeiro acesso.</p>
<?php if($erro): ?><div class="alerta erro"><?=h($erro)?></div><?php endif; ?>
<form method="post" class="formulario"><input type="hidden" name="csrf" value="<?=h(token_csrf())?>"><input type="hidden" name="acao" value="entrar">
<label for="email">E-mail</label><input id="email" name="email" type="email" autocomplete="username" required>
<label for="senha">Senha</label><input id="senha" name="senha" type="password" autocomplete="current-password" required>
<button type="submit">Entrar</button></form>
<details class="painel"><summary>Primeiro acesso? Criar conta de administrador</summary><form method="post" class="formulario"><input type="hidden" name="csrf" value="<?=h(token_csrf())?>"><input type="hidden" name="acao" value="cadastro">
<label for="nome">Nome</label><input id="nome" name="nome" maxlength="120" required><label for="email2">E-mail</label><input id="email2" name="email" type="email" required><label for="senha2">Senha (mínimo 8 caracteres)</label><input id="senha2" name="senha" type="password" minlength="8" required><button type="submit">Criar conta</button></form></details>
<p class="nota">A senha é armazenada com hash. O sistema funciona localmente com MySQL/PDO.</p></main></body></html>
