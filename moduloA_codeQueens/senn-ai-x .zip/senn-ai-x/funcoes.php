<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/conexao.php';

function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function logado(): bool { return isset($_SESSION['usuario_id']); }
function exigir_login(): void { if (!logado()) { header('Location: login.php'); exit; } }
function token_csrf(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function validar_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $sent = $_POST['csrf'] ?? '';
        if (!is_string($sent) || !hash_equals(token_csrf(), $sent)) {
            http_response_code(403); exit('Sessão expirada ou formulário inválido. Volte e tente novamente.');
        }
    }
}
function flash(string $msg, string $tipo='ok'): void { $_SESSION['flash'] = [$msg, $tipo]; }
function mostrar_flash(): void {
    if (!empty($_SESSION['flash'])) {
        [$msg,$tipo] = $_SESSION['flash']; unset($_SESSION['flash']);
        echo '<div class="alerta '.h($tipo).'">'.h($msg).'</div>';
    }
}
function layout_inicio(string $titulo, string $ativo=''): void {
    $links = [
      'Painel'=>'index.php','Entregas'=>'entregas.php','Veículos'=>'veiculos.php',
      'Motoristas'=>'motoristas.php','Rotas'=>'rotas.php','Rastreamento'=>'rastreamento.php',
      'Comprovantes'=>'comprovantes.php','IA e indicadores'=>'ia.php','Alertas'=>'alertas.php'
    ];
    echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>'.h($titulo).' | SENN AI-X</title><link rel="stylesheet" href="style.css"></head><body>';
    echo '<header class="topo"><a class="logo" href="index.php">SENN <span>AI-X</span></a><div class="usuario">'.h($_SESSION['usuario_nome'] ?? 'Operação').'<a class="sair" href="login.php?sair=1">Sair</a></div></header>';
    echo '<div class="layout"><aside class="menu"><h3>OPERAÇÃO</h3>';
    foreach ($links as $nome=>$url) echo '<a '.($ativo===$nome?'class="ativo"':'').' href="'.h($url).'">'.h($nome).'</a>';
    echo '</aside><main class="conteudo"><div class="titulo-pagina"><div><h1>'.h($titulo).'</h1></div></div>';
    mostrar_flash();
}
function layout_fim(): void { echo '</main></div><footer class="rodape">SENN AI-X · Gestão logística · Ambiente local</footer></body></html>'; }
function gerar_alerta(PDO $pdo, string $tipo, string $descricao): void {
    $q=$pdo->prepare("SELECT id FROM alertas WHERE tipo=? AND descricao=? AND resolvido=0 LIMIT 1");
    $q->execute([$tipo,$descricao]);
    if (!$q->fetch()) { $q=$pdo->prepare("INSERT INTO alertas(tipo,descricao,resolvido) VALUES(?,?,0)"); $q->execute([$tipo,$descricao]); }
}
function status_entrega_valido(string $s): bool { return in_array($s,['Pendente','A caminho','Entregue','Falha'],true); }
