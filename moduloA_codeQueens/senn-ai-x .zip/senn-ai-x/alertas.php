<?php
require_once 'funcoes.php'; exigir_login(); validar_csrf();
if($_SERVER['REQUEST_METHOD']==='POST'){
 $a=$_POST['acao']??'';$id=(int)($_POST['id']??0);
 if($a==='resolver'&&$id){$q=$pdo->prepare('UPDATE alertas SET resolvido=1 WHERE id=?');$q->execute([$id]);$q=$pdo->prepare("INSERT INTO logs_notificacoes(alerta_id,canal,resultado) VALUES(?,'painel','marcado como resolvido')");try{$q->execute([$id]);}catch(Throwable $e){}flash('Alerta marcado como resolvido.');header('Location: alertas.php');exit;}
 if($a==='gerar'){
  $q=$pdo->query("SELECT codigo,janela_entrega FROM entregas WHERE status IN ('Pendente','A caminho') AND janela_entrega IS NOT NULL AND janela_entrega < NOW()");
  foreach($q as $e)gerar_alerta($pdo,'Entrega atrasada','Entrega '.$e['codigo'].' passou da janela '.$e['janela_entrega'].'.');
  $q=$pdo->query("SELECT placa,proxima_manutencao FROM veiculos WHERE proxima_manutencao IS NOT NULL AND proxima_manutencao <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)");
  foreach($q as $v)gerar_alerta($pdo,'Manutenção próxima','Veículo '.$v['placa'].' possui manutenção em '.$v['proxima_manutencao'].'.');
  $q=$pdo->query("SELECT nome,validade_cnh FROM motoristas WHERE validade_cnh IS NOT NULL AND validade_cnh <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)");
  foreach($q as $m)gerar_alerta($pdo,'CNH a vencer','CNH de '.$m['nome'].' vence em '.$m['validade_cnh'].'.');
  flash('Verificação concluída. Os alertas identificados foram registrados no painel.');header('Location: alertas.php');exit;
 }
}
$lista=$pdo->query('SELECT * FROM alertas ORDER BY resolvido ASC,criado_em DESC')->fetchAll();layout_inicio('Alertas e notificações','Alertas');
?>
<p class="subtitulo">Verificação de prazos, manutenção e CNH. Os alertas são registrados no painel; envio de e-mail requer configuração SMTP.</p><section class="painel"><form method="post"><input type="hidden" name="csrf" value="<?=h(token_csrf())?>"><input type="hidden" name="acao" value="gerar"><button>Verificar prazos e gerar alertas</button></form></section>
<section class="painel"><h2>Central de alertas</h2><div class="tabela-responsiva"><table><thead><tr><th>Data</th><th>Tipo</th><th>Descrição</th><th>Situação</th><th>Ação</th></tr></thead><tbody><?php foreach($lista as $a):?><tr><td><?=h($a['criado_em'])?></td><td><?=h($a['tipo'])?></td><td><?=h($a['descricao'])?></td><td><?=$a['resolvido']?'Resolvido':'Aberto'?></td><td><?php if(!$a['resolvido']):?><form method="post"><input type="hidden" name="csrf" value="<?=h(token_csrf())?>"><input type="hidden" name="acao" value="resolver"><input type="hidden" name="id" value="<?=(int)$a['id']?>"><button>Resolver</button></form><?php else:?>—<?php endif;?></td></tr><?php endforeach;?><?php if(!$lista):?><tr><td colspan="5">Nenhum alerta registrado.</td></tr><?php endif;?></tbody></table></div></section><?php layout_fim();?>
